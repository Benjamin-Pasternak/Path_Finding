# Path_Finding
Project 1 CS 440: Using repeated forward A* to solve mazes!

Run A*.py
